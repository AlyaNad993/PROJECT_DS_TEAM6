#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define the structure for the linked list node
typedef struct Node {
    char state[30];
    struct Node* next;
} Node;


// Function prototypes
Node* createNode(const char* state);
void insertAtEnd(Node** head, const char* state);
void displayList(Node* head);
void displayReverse(Node* head);
void bubbleSort(Node** head, int ascending);
Node* searchNode(Node* head, const char* state);
void deleteNode(Node** head, const char* state);
void freeList(Node** head);

int main() {
    Node* head = NULL;
    int choice;
    char searchState[30], deleteState[30];
    
    // Initial list of Malaysian states and federal territories
    const char* malaysianStates[] = {
        "Johore", "Kelantan", "Sabah", "Perak", "Kedah", 
        "Malacca", "Putrajaya", "Pahang", "Perlis", "Labuan", 
        "Negeri Sembilan", "Sarawak", "Pulau Pinang", "Selangor", 
        "Terengganu", "Kuala Lumpur"
    };
    
    // Create the initial linked list
    printf("Creating the linked list with Malaysian states and territories...\n");
    int i;
    for (i = 0; i < 16; i++) {
        insertAtEnd(&head, malaysianStates[i]);
    }
    
    // Menu-driven program
    do {
        printf("\n\n--- Malaysian States and Territories Linked List Operations ---\n");
        printf("1. Display the list\n");
        printf("2. Sort in ascending order\n");
        printf("3. Sort in descending order\n");
        printf("4. Search for a state/territory\n");
        printf("5. Delete a state/territory\n");
        printf("6. Insert a new state/territory\n");
        printf("0. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                printf("\nCurrent list of Malaysian states and territories:\n");
                displayList(head);
                break;
                
            case 2:
                bubbleSort(&head, 1);  // 1 for ascending
                printf("\nList sorted in ascending order:\n");
                displayList(head);
                break;
                
            case 3:
                bubbleSort(&head, 0);  // 0 for descending
                printf("\nList sorted in descending order:\n");
                displayList(head);
                break;
                
            case 4:
                printf("\nEnter the state/territory to search: ");
                scanf(" %[^\n]", searchState);
                Node* result = searchNode(head, searchState);
                if (result) {
                    printf("'%s' found in the list!\n", searchState);
                } else {
                    printf("'%s' not found in the list.\n", searchState);
                }
                break;
                
            case 5:
                printf("\nEnter the state/territory to delete: ");
                scanf(" %[^\n]", deleteState);
                deleteNode(&head, deleteState);
                printf("Updated list:\n");
                displayList(head);
                break;
                
            case 6:
                printf("\nEnter the state/territory to insert: ");
                scanf(" %[^\n]", searchState);
                insertAtEnd(&head, searchState);
                printf("Updated list:\n");
                displayList(head);
                break;
                
            case 0:
                printf("\nExiting program. Cleaning up...\n");
                break;
                
            default:
                printf("\nInvalid choice. Please try again.\n");
        }
    } while (choice != 0);
    
    // Free the memory
    freeList(&head);
    
    return 0;
}

// Function to create a new node
Node* createNode(const char* state) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Memory allocation failed.\n");
        exit(1);
    }
    strcpy(newNode->state, state);
    newNode->next = NULL;
    return newNode;
}

// Function to insert a node at the end of the list
void insertAtEnd(Node** head, const char* state) {
    Node* newNode = createNode(state);
    
    // If the list is empty
    if (*head == NULL) {
        *head = newNode;
        return;
    }
    
    // Traverse to the end of the list
    Node* temp = *head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    
    // Insert at the end
    temp->next = newNode;
}

// Function to display the linked list
void displayList(Node* head) {
    if (head == NULL) {
        printf("The list is empty.\n");
        return;
    }
    
    Node* temp = head;
    int count = 1;
    while (temp != NULL) {
        printf("%d. %s\n", count++, temp->state);
        temp = temp->next;
    }
}

// Helper function to display a linked list in reverse order (recursive)
void displayReverseHelper(Node* node) {
    if (node == NULL) {
        return;
    }
    
    displayReverseHelper(node->next);
    printf("%s\n", node->state);
}

// Function to display the linked list in reverse order
void displayReverse(Node* head) {
    if (head == NULL) {
        printf("The list is empty.\n");
        return;
    }
    
    displayReverseHelper(head);
}

// Function to sort the linked list using bubble sort
void bubbleSort(Node** head, int ascending) {
    if (*head == NULL || (*head)->next == NULL) {
        return;  // No need to sort if list is empty or has only one node
    }
    
    int swapped;
    Node* ptr1;
    Node* lptr = NULL;
    
    do {
        swapped = 0;
        ptr1 = *head;
        
        while (ptr1->next != lptr) {
            int comparison = strcmp(ptr1->state, ptr1->next->state);
            
            // For ascending: swap if current > next
            // For descending: swap if current < next
            if ((ascending && comparison > 0) || (!ascending && comparison < 0)) {
                // Swap the data
                char temp[30];
                strcpy(temp, ptr1->state);
                strcpy(ptr1->state, ptr1->next->state);
                strcpy(ptr1->next->state, temp);
                swapped = 1;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    } while (swapped);
}

// Function to search for a node by state name
Node* searchNode(Node* head, const char* state) {
    Node* current = head;
    
    while (current != NULL) {
        if (strcmp(current->state, state) == 0) {
            return current;  // Found
        }
        current = current->next;
    }
    
    return NULL;  // Not found
}

// Function to delete a node by state name
void deleteNode(Node** head, const char* state) {
    // If list is empty
    if (*head == NULL) {
        printf("The list is empty. Nothing to delete.\n");
        return;
    }
    
    Node* temp = *head;
    Node* prev = NULL;
    
    // If head node itself holds the state to be deleted
    if (temp != NULL && strcmp(temp->state, state) == 0) {
        *head = temp->next;  // Changed head
        free(temp);          // Free old head
        printf("'%s' has been deleted from the list.\n", state);
        return;
    }
    
    // Search for the state to be deleted, keep track of the previous node
    while (temp != NULL && strcmp(temp->state, state) != 0) {
        prev = temp;
        temp = temp->next;
    }
    
    // If the state wasn't present in the list
    if (temp == NULL) {
        printf("'%s' not found in the list.\n", state);
        return;
    }
    
    // Unlink the node from the linked list
    prev->next = temp->next;
    free(temp);  // Free memory
    printf("'%s' has been deleted from the list.\n", state);
}

// Function to free the entire linked list
void freeList(Node** head) {
    Node* current = *head;
    Node* next;
    
    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }
    
    *head = NULL;
}
